import React, { Component, Fragment } from "react";
import ReactDOM from "react-dom";

import cydtVideo from "./assets/video/video_x264.mp4";

export default class Video extends Component {
  render() {
    return (
      <video
        style={{ position: "absolute", zIndex: 999999, left: 0, top: 0, width: "100%", height: "100%" }}
        src={cydtVideo}
        autoPlay="autoplay"
        loop="loop"
      />
    );
  }
}
